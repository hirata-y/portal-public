# P3-B1 Local synthetic technology PoC — INTERIM / NOT OFFICIAL FREEZE

**Version:** working snapshot 2026-10-15; **Producer self-check:** 59/59 PASS (limited). **F independent review:** NOT EXECUTED. **G4:** NOT APPROVED.

The Owner authorized P3-A local-synthetic-only conditional acceptance and progress to P3-B1. Prior F review BLOCKED remains unchanged. Original P2 v1.1.6 and P3-A v0.1.0 ZIP are immutable SHA-pinned inputs. No Cloudflare/GitHub/environment/production content was changed.

## Layout

- `source/p3_a_site/`: exact byte copies of 16 original P3-A source members.
- `outputs/public/`: exact original P3-A static site + B1 experimental offline index and 4 clearly synthetic format fixtures. Serve locally from this directory. This is a **synthetic PoC**, not an authorized public website.
- `outputs/members/`: a SEPARATE synthetic members-only canary with no password/real data. It is deliberately not present in public output. **There is no real authentication.**
- `astro_candidate/`: Astro + Pagefind starter structure for evaluation; source-only, no node_modules, no lockfile, **no actual Astro build or Pagefind index**. Do NOT assume it works until tested in a dependency-enabled environment.
- `tools/verify_b1.py`: reproducible Python baseline, leak-check, negative probes, static HTTP, format parse tests; produces `evidence/test_expected_actual.json`.
- `tools/run_vendor_probe_windows.ps1`: optional local npm/Astro/Pagefind build script, if the Owner authorizes running it on an npm-connectable Windows machine. It writes installation and build outputs under `evidence/windows_vendor_probe` and does not publish.
- `docs/`: design options, provenance, security controls, CT01–07, G4 stop list.

## What really ran

1. Verified P2 Full and P3-A Full raw SHA256.
2. Copied and hashed 16 original source files byte-for-byte unchanged.
3. Rebuilt a derived local JSON index of the exact 8 P3-A synthetic records, confirmed Japanese substring baseline scenarios (NOT Pagefind).
4. Generated separate public/member synthetic bundles; canary invisible in public bytes. Confirmed mutation detector catches intentionally introduced canary/duplicate/traversal in **temporary test data**, not public artifact.
5. Generated and parsed 4 synthetic format specimens HTML/PDF/PPTX/XLSX; not validated semantic fidelity from real originals.
6. Exercised local Python HTTP loopback 7 public files (and verified private canary URL missing) and stored expected/actual results.
7. Attempted actual npm dependency resolution: `EAI_AGAIN`. Astro & Pagefind binaries unavailable so these vendor tests remain NOT_EXECUTED; any vendor performance or search accuracy comparison is pending.

Run self-check (requires Python, fitz, reportlab, pptx, artifact_tool to regenerate formats; for verify, fitz only plus stdlib):

```shell
python tools/verify_b1.py
cd outputs/public
python -m http.server 8766 --bind 127.0.0.1
```

On Windows, Node/npm-connected authorized user may run `powershell -ExecutionPolicy Bypass -File tools/run_vendor_probe_windows.ps1` from the extracted working tree after reviewing the commands, then submit install/build/search/browser evidence. This is outside the 59 PASS and does not automatically mean G4/QA approved.

**Safety:** all content is synthetic. Do not host `outputs/members` publicly or copy it into `outputs/public`; zero real JWT, identities, credentials, customer data, production readers or Cloudflare changes. Do not use test route difficulty as mountaineering information.
